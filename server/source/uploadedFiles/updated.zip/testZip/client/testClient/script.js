// const uploadInput = document.querySelector('#upload');
// uploadInput.addEventListener('change', (e) => {
//     console.log(e.target.files);
// });
