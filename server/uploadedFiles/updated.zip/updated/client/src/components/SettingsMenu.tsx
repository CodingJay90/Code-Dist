import React, {useState} from 'react';
import {useSetRecoilState} from 'recoil';
import {showAdminModalState} from '../atoms/AdminConsole';

import {showModalState} from '../atoms/ChangeUserModalState';
import {showSettingsMenuState} from '../atoms/SettingsMenuState';

enum DropDownItem {
  ADMIN = 'Admin Console',
  CHANGE_USER = 'Change User',
  SETTINGS = 'Settings',
  Help = 'Help',
}

const styles: {[key: string]: React.CSSProperties} = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
  },
  menu: {
    display: 'flex',
    flexDirection: 'column',
    position: 'absolute',
    left: 'calc(100vw - 220px)',
    top: '90px',
    width: '180px',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    borderRadius: '5px',
    boxShadow:
      '0px 6px 20px 0px rgba(176, 190, 197, 0.32), 0px 2px 4px 0px rgba(176, 190, 197, 0.32)',
    padding: '10px',
  },
  menuItem: {
    padding: '10px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'default',
    flex: 1,
    display: 'flex',
    justifyContent: 'flex-start',
  },
};

const SettingsMenuItemType = Object.freeze({
  SETTINGS: 'SETTINGS',
  HELP: 'HELP',
  ADMIN_CONSOLE: 'ADMIN_CONSOLE',
  CHANGE_USER: 'CHANGE_USER',
});

const SettingsMenuItemConfigs = [
  {
    type: SettingsMenuItemType.SETTINGS,
    label: DropDownItem.SETTINGS,
    onClick: () => {},
  },
  {
    type: SettingsMenuItemType.HELP,
    label: DropDownItem.Help,
    onClick: () => {},
  },
  {
    type: SettingsMenuItemType.ADMIN_CONSOLE,
    label: DropDownItem.ADMIN,
    onClick: (setShowAdminModalState: (state: boolean) => void) => {
      setShowAdminModalState(true);
    },
  },
  {
    type: SettingsMenuItemType.CHANGE_USER,
    label: DropDownItem.CHANGE_USER,
    onClick: (setShowChangeUserModal: (value: boolean) => void) =>
      setShowChangeUserModal(true),
  },
];

const SettingsMenu = () => {
  const setShowChangeUserModal = useSetRecoilState(showModalState);
  const setShowSettingsMenu = useSetRecoilState(showSettingsMenuState);
  const setShowAdminModalState = useSetRecoilState(showAdminModalState);
  const [hoveredMenuItemKey, setHoveredMenuItemKey] = useState<number | null>(
    null
  );

  const clickEventMatcher: {[key: string]: (state: boolean) => void} = {
    [DropDownItem.ADMIN]: setShowAdminModalState,
    [DropDownItem.CHANGE_USER]: setShowChangeUserModal,
  };

  return (
    <div style={styles.overlay} onClick={() => setShowSettingsMenu(false)}>
      <div style={styles.menu}>
        {SettingsMenuItemConfigs.map((menuItem, idx) => (
          <div
            key={idx}
            style={{
              ...styles.menuItem,
              backgroundColor:
                hoveredMenuItemKey === idx ? '#EEEEEE' : '#FFFFFF',
            }}
            onClick={() => {
              setShowSettingsMenu(false);
              menuItem.onClick(clickEventMatcher[menuItem.label]);
            }}
            onMouseEnter={() => setHoveredMenuItemKey(idx)}
            onMouseLeave={() => setHoveredMenuItemKey(null)}
          >
            {menuItem.label}
          </div>
        ))}
      </div>
    </div>
  );
};

export default SettingsMenu;
