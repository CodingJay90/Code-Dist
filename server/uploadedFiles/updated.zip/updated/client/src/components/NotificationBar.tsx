import {useMutation} from '@apollo/client';
import React, {FC} from 'react';
import {useRecoilState, useRecoilValue} from 'recoil';
import {DISABLE_USER_WARNING} from '../graphql/mutation';
import {currentUserState} from '../atoms/UserState';
import {User} from '../models/User';
import {activeWarning} from '../atoms/ActiveWarning';
import Logger from '../utils/Logger';
import {formatWarningType} from '../utils/formatter';

const styles: {[key: string]: React.CSSProperties} = {
  container: {
    backgroundColor: '#F47564',
    padding: '0.9rem 1rem',
  },
  flexWrapper: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  label: {
    margin: '0',
    color: '#fff',
    fontSize: '0.8rem',
    fontWeight: '500',
  },
  button: {
    backgroundColor: '#414141',
    border: 'none',
    padding: '0.4rem 0.6rem',
    borderRadius: '0.2rem',
    color: '#fff',
    cursor: 'pointer',
  },
};

interface IProps {
  _id: string;
  type: string;
  label: string;
  enabled: boolean;
}

const WarningBar: FC<IProps> = ({label}) => {
  const [disableUserWarning] = useMutation<User, {_id: string}>(
    DISABLE_USER_WARNING
  );
  const [activeWarningState, setActiveWarning] = useRecoilState(activeWarning);
  const currentUser = useRecoilValue(currentUserState);

  async function onDismissWarning(): Promise<void> {
    try {
      if (!currentUser?._id) return;
      const {errors} = await disableUserWarning({
        variables: {_id: currentUser._id},
      });
      if (errors) return alert('an error occurred');
      Logger.info(
        `Ended ${formatWarningType(activeWarningState?.type || 'warning')}`
      );
      setActiveWarning(null);
    } catch (error) {
      alert('an error occurred');
    }
  }
  return (
    <>
      <div style={styles.container}>
        <div style={styles.flexWrapper}>
          <h5 style={styles.label}>{label}</h5>
          <button onClick={onDismissWarning} style={styles.button}>
            Dismiss
          </button>
        </div>
      </div>
    </>
  );
};

export default WarningBar;
