import React, {useState} from 'react';
import {useQuery} from '@apollo/client';
import {useSetRecoilState} from 'recoil';
import LoadingOverlay from '../LoadingOverlay';
import ErrorOverlay from '../ErrorOverlay';
import {showAdminModalState} from '../../atoms/AdminConsole';
import AdminDropDown from './AdminDropDown';
import AdminConsoleFooter from './AdminConsoleFooter';
import DropDownTrigger from './DropDownTrigger';
import {GET_NOTIFICATIONS} from '../../graphql/queries';
import {WarningGQLResponse} from '../../models/Warning';

const styles: {[key: string]: React.CSSProperties} = {
  root: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'fixed',
    left: '0',
    top: '0',
    height: '100vh',
    width: '100vw',
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
    backdropFilter: 'blur(8px)',
  },
  heading: {
    fontSize: '1.5rem',
    marginBottom: '0',
  },
  subHeading: {
    marginBottom: '0.5rem',
  },
  modal: {
    width: '500px',
    height: '270px',
    borderRadius: '10px',
    backgroundColor: 'rgba(255, 255, 255, 1)',
    paddingLeft: '20px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    color: '#414141',
    boxShadow:
      '0px 6px 20px 0px rgba(176, 190, 197, 0.32), 0px 2px 4px 0px rgba(176, 190, 197, 0.32)',
  },
  rotate180: {
    transform: 'rotate(180deg)',
  },
};

const AdminConsoleModal = () => {
  const [showDropdown, setShowDropdown] = useState<boolean>(false);
  const setShowAdminModalState = useSetRecoilState(showAdminModalState);

  const {data, loading, error} =
    useQuery<WarningGQLResponse>(GET_NOTIFICATIONS);

  if (loading) return <LoadingOverlay />;
  if (error) return <ErrorOverlay />;

  return (
    <>
      <div style={styles.root} onClick={() => setShowAdminModalState(false)}>
        <div
          style={styles.modal}
          onClick={e => {
            e.stopPropagation();
            setShowDropdown(false);
          }}
        >
          <h1 style={styles.heading}>Admin Console</h1>
          <h4 style={styles.subHeading}>Start a site-side warning</h4>
          <DropDownTrigger
            showDropdown={showDropdown}
            setShowDropdown={setShowDropdown}
            currentEnabledWarning={data?.getWarnings.find(
              i => i.enabled === true
            )}
          />
          {showDropdown ? (
            <AdminDropDown notificationsData={data?.getWarnings} />
          ) : null}
          <AdminConsoleFooter
            setShowAdminModalState={setShowAdminModalState}
            setShowDropdown={setShowDropdown}
            currentEnabledWarning={data?.getWarnings.find(
              i => i.enabled === true
            )}
          />
        </div>
      </div>
    </>
  );
};

export default AdminConsoleModal;
