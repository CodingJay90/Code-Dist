import {useMutation} from '@apollo/client';
import React, {useState, FC} from 'react';
import {useRecoilValue, useSetRecoilState} from 'recoil';
import {activeWarning} from '../../atoms/ActiveWarning';
import {selectedWarning} from '../../atoms/AdminConsole';
import {
  ENABLE_WARNING,
  UPDATE_USERS_WARNING,
  DISABLE_USERS_WARNING,
} from '../../graphql/mutation';
import {Warning} from '../../models/Warning';
import {formatWarningType} from '../../utils/formatter';
import Logger from '../../utils/Logger';

const styles: {[key: string]: React.CSSProperties} = {
  footer: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    width: '450px',
    padding: '20px',
    fontWeight: 600,
  },
  cancelButton: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#EDEDED',
    width: '140px',
    height: '45px',
    borderRadius: '5px',
    marginRight: '15px',
    cursor: 'pointer',
    border: 'none',
    color: '#000',
  },
  startWarningButton: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F47564',
    width: '140px',
    height: '45px',
    borderRadius: '5px',
    cursor: 'pointer',
    border: 'none',
    color: '#fff',
  },
  endWarningButton: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ABEFEB',
    width: '140px',
    height: '45px',
    borderRadius: '5px',
    cursor: 'pointer',
    border: 'none',
    color: '#000',
    marginRight: '15px',
  },
  endWarningButtonDisabled: {
    opacity: 0.5,
    cursor: 'default',
  },
  startWarningButtonDisabled: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FABAB1',
    opacity: 0.8,
    width: '140px',
    height: '45px',
    borderRadius: '5px',
    cursor: 'default',
    border: 'none',
    color: '#fff',
  },
};

interface IProps {
  setShowDropdown: (state: boolean) => void;
  setShowAdminModalState: (state: boolean) => void;
  currentEnabledWarning: Warning | undefined;
}

interface EnableWarningPayload {
  _id: string;
  record: {
    enabled: boolean;
  };
}

interface EnableUsersPayload {
  label: string;
  type: string;
}

interface EnableWarningRes {
  record: {
    _id: string;
    type: string;
    label: string;
    enabled: boolean;
  };
}

const AdminConsoleFooter: FC<IProps> = ({
  setShowAdminModalState,
  setShowDropdown,
  currentEnabledWarning,
}) => {
  const [cancelButtonOpacity, setCancelButtonOpacity] = useState(1.0);
  const selectedWarningState = useRecoilValue(selectedWarning);
  const setActiveWarning = useSetRecoilState(activeWarning);
  const activeWarningState = useRecoilValue(activeWarning);

  const [enableWarning] = useMutation<
    {updateWarningById: EnableWarningRes},
    EnableWarningPayload
  >(ENABLE_WARNING);
  const [enableUsersWarnings] = useMutation<string, EnableUsersPayload>(
    UPDATE_USERS_WARNING
  );
  const [disableUsersWarnings] = useMutation<void, string>(
    DISABLE_USERS_WARNING
  );

  async function handleStartWarning(): Promise<void> {
    try {
      if (currentEnabledWarning) {
        handleEndWarning();
      }
      const {data, errors} = await enableWarning({
        variables: {
          _id: selectedWarningState!._id, // as Pick<Warning, '_id'>,
          record: {
            enabled: true,
          },
        },
      });
      const warningRes = data?.updateWarningById.record as Warning;
      if (errors) return alert('an error occurred');
      await enableUsersWarnings({
        variables: {
          label: warningRes.label,
          type: warningRes.type,
        },
      });
      setActiveWarning(warningRes);
      setShowDropdown(false);
      setShowAdminModalState(false);
      Logger.info(`Started ${formatWarningType(warningRes.type)}`);
    } catch (error) {
      alert('an error occurred');
    }
  }

  async function handleEndWarning(): Promise<void> {
    try {
      const {errors} = await enableWarning({
        variables: {
          _id: currentEnabledWarning!._id, // as Pick<Warning, '_id'>,
          record: {
            enabled: false,
          },
        },
      });
      if (errors) return alert('an error occurred');
      await disableUsersWarnings();

      setShowDropdown(false);
      setShowAdminModalState(false);
      setActiveWarning(null);
      Logger.info(
        `Ended ${formatWarningType(activeWarningState?.type || 'warning')}`
      );
    } catch (error) {
      alert('an error occurred ');
    }
  }

  const endWarningBtnDisabled =
    currentEnabledWarning?.type !== selectedWarningState?.type;
  const startWarningBtnDisabled =
    selectedWarningState === null ||
    currentEnabledWarning?.type === selectedWarningState?.type;

  return (
    <>
      <div style={styles.footer}>
        <button
          style={{...styles.cancelButton, opacity: cancelButtonOpacity}}
          onClick={() => {
            setShowDropdown(false);
            setShowAdminModalState(false);
          }}
          onMouseEnter={() => setCancelButtonOpacity(0.8)}
          onMouseLeave={() => setCancelButtonOpacity(1.0)}
          data-testid="cancel-btn"
        >
          Cancel
        </button>
        {activeWarning !== null && currentEnabledWarning && (
          <button
            style={{
              opacity: cancelButtonOpacity,
              ...styles.endWarningButton,
              ...(endWarningBtnDisabled && styles.endWarningButtonDisabled),
            }}
            onClick={e => {
              e.stopPropagation();
              handleEndWarning();
            }}
            disabled={endWarningBtnDisabled}
          >
            End Warning
          </button>
        )}

        <button
          style={{
            ...(startWarningBtnDisabled
              ? styles.startWarningButtonDisabled
              : styles.startWarningButton),
          }}
          disabled={startWarningBtnDisabled}
          onClick={event => {
            event.stopPropagation();
            handleStartWarning();
          }}
        >
          Start Warning
        </button>
      </div>
    </>
  );
};

export default AdminConsoleFooter;
