import React, {useState, FC} from 'react';
import {useSetRecoilState} from 'recoil';
import {selectedWarning} from '../../atoms/AdminConsole';
import {Warning} from '../../models/Warning';
import {formatWarningType} from '../../utils/formatter';

const styles: {[key: string]: React.CSSProperties} = {
  dropdown: {
    display: 'flex',
    flexDirection: 'column',
    position: 'absolute',
    width: '450px',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    borderRadius: '5px',
    borderStyle: 'solid',
    borderWidth: '1px',
    borderColor: '#C6C6C6',
    padding: '10px 8px',
    marginTop: '177px',
    backgroundColor: '#FFFFFF',
    zIndex: 1,
  },
  menuContainer: {
    display: 'flex',
    flexDirection: 'column',
    listStyle: 'none',
    paddingLeft: '0',
    margin: '0',
  },
  menuItem: {
    cursor: 'pointer',
    padding: '0.6rem',
  },
  menuItemHeading: {
    margin: '0',
    textAlign: 'left',
    fontSize: '0.9rem',
    color: ' #414141',
  },
  menuItemLabel: {
    margin: '0',
    textAlign: 'left',
    fontSize: '0.8rem',
    color: ' #A5A5A5',
  },
};

interface IProps {
  notificationsData: Warning[] | undefined;
}

const AdminDropDown: FC<IProps> = ({notificationsData}) => {
  const [hoverStyle, setHoverStyle] = useState<string>('#fff');
  const [hoveredMenuItemKey, setHoveredMenuItemKey] = useState<string | null>(
    null
  );
  const setSelectedWarning = useSetRecoilState(selectedWarning);
  return (
    <div style={styles.dropdown}>
      <ul style={styles.menuContainer}>
        {notificationsData?.length ? (
          notificationsData.map((i, index) => (
            <li
              key={i._id}
              style={{
                ...styles.menuItem,
                ...(hoveredMenuItemKey === i._id && {
                  backgroundColor: hoverStyle,
                }),
              }}
              onClick={() => {
                setSelectedWarning(i);
              }}
              onMouseEnter={() => {
                setHoveredMenuItemKey(i._id);
                setHoverStyle('#EEEEEE');
              }}
              data-testid={'dropdown' + index}
              onMouseLeave={() => setHoverStyle('#fff')}
            >
              <h5 style={styles.menuItemHeading}>
                {formatWarningType(i.type)}
              </h5>
              <p style={styles.menuItemLabel}>{i.label}</p>
            </li>
          ))
        ) : (
          <p>No Warnings</p>
        )}
      </ul>
    </div>
  );
};

export default AdminDropDown;
