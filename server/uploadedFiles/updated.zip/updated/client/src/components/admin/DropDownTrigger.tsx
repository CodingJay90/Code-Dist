import React, {FC, useEffect, useState} from 'react';
import {GoChevronDown, GoChevronUp} from 'react-icons/go';
import {useRecoilValue, useSetRecoilState} from 'recoil';
import {activeWarning} from '../../atoms/ActiveWarning';
import {selectedWarning} from '../../atoms/AdminConsole';
import {Warning} from '../../models/Warning';
import {formatWarningType} from '../../utils/formatter';

const styles: {[key: string]: React.CSSProperties} = {
  dropdownButton: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderColor: '#C6C6C6',
    borderRadius: '5px',
    borderStyle: 'solid',
    borderWidth: '1px',
    paddingLeft: '10px',
    paddingRight: '10px',
    width: '450px',
    height: '60px',
    cursor: 'pointer',
  },
  rotate180: {
    transform: 'rotate(180deg)',
  },
};

interface IProps {
  showDropdown: boolean;
  setShowDropdown: (state: boolean) => void;
  currentEnabledWarning: Warning | undefined;
}
const DropDownTrigger: FC<IProps> = ({
  showDropdown,
  setShowDropdown,
  currentEnabledWarning,
}) => {
  const selectedWarningState = useRecoilValue(selectedWarning);
  const activeWarningState = useRecoilValue(activeWarning);
  const setSelectedWarningState = useSetRecoilState(selectedWarning);
  const [selectedWarningLabel, setSelectedWarningLabel] = useState<
    string | undefined
  >('');
  const ChevronIcon = showDropdown ? GoChevronUp : GoChevronDown;

  useEffect(() => {
    setSelectedWarningLabel(selectedWarningState?.type);
    if (currentEnabledWarning && !selectedWarningState) {
      setSelectedWarningLabel(currentEnabledWarning?.type);
      setSelectedWarningState(currentEnabledWarning);
    }
  }, [activeWarningState, selectedWarningState]);

  return (
    <>
      {' '}
      <div
        style={styles.dropdownButton}
        onClick={e => {
          e.stopPropagation();
          setShowDropdown(!showDropdown);
        }}
      >
        <div>
          {selectedWarningLabel && formatWarningType(selectedWarningLabel)}
        </div>
        <ChevronIcon size={30} />
      </div>
    </>
  );
};

export default DropDownTrigger;
