import {useRecoilValue} from 'recoil';

import './App.css';
import {showAdminModalState} from './atoms/AdminConsole';
import {showModalState} from './atoms/ChangeUserModalState';
import {showSettingsMenuState} from './atoms/SettingsMenuState';
import AdminConsoleModal from './components/admin/AdminConsoleModal';
import ChangeUserModal from './components/ChangeUserModal';
import SettingsMenu from './components/SettingsMenu';
import HomeScreen from './containers/HomeScreen';

const App = () => {
  const showChangeUserModal = useRecoilValue(showModalState);
  const showSettingsMenu = useRecoilValue(showSettingsMenuState);
  const showAdminConsole = useRecoilValue(showAdminModalState);

  return (
    <div className="App">
      <HomeScreen />
      {showChangeUserModal ? <ChangeUserModal /> : null}
      {showAdminConsole ? <AdminConsoleModal /> : null}
      {showSettingsMenu ? <SettingsMenu /> : null}
    </div>
  );
};

export default App;
