import React, {useEffect} from 'react';
import {useQuery, gql, useLazyQuery} from '@apollo/client';
import GlobalHeader from '../components/GlobalHeader';
import LeftNav from '../components/LeftNav';
import ScreenContent from '../components/ScreenContent';
import {User, UserGQLResponse} from '../models/User';
import LoadingOverlay from '../components/LoadingOverlay';
import ErrorOverlay from '../components/ErrorOverlay';
import {useRecoilState, useRecoilValue, useSetRecoilState} from 'recoil';
import {activeWarning} from '../atoms/ActiveWarning';
import WarningBar from '../components/NotificationBar';
import {GET_USER_DETAILS} from '../graphql/queries';
import {Warning} from '../models/Warning';
import {currentUserState} from '../atoms/UserState';

interface UserOneData {
  userOne: UserGQLResponse;
}

interface UserDetailRes {
  userById: {
    activeWarning: {
      _id: string;
      type: string;
      label: string;
      enabled: boolean;
    };
  };
}

const GET_USER = gql`
  query GetUser {
    userOne {
      _id
      firstName
      lastName
      email
    }
  }
`;

const styles: {[key: string]: React.CSSProperties} = {
  leftNavAndScreenContent: {
    display: 'flex',
    flexDirection: 'row',
    height: 'calc(100vh - 80px)',
  },
};

const HomeScreen = () => {
  const {loading, error, data} = useQuery<UserOneData, {}>(GET_USER);
  const [getUserWarningData, {...userData}] = useLazyQuery<
    UserDetailRes,
    {_id: string}
  >(GET_USER_DETAILS);
  const activeWarningState = useRecoilValue(activeWarning);
  const setActiveWarning = useSetRecoilState(activeWarning);
  const [currentUser, setCurrentUser] = useRecoilState(currentUserState);
  const userWarningData = {...userData.data?.userById.activeWarning} as Warning;

  useEffect(() => {
    if (data?.userOne) {
      getUserWarningData({
        variables: {_id: currentUser?._id || data.userOne._id},
      });
      const u = currentUser || (data.userOne as unknown);
      setCurrentUser(u as User);
    }
  }, [data, currentUser]);

  useEffect(() => {
    setActiveWarning(userWarningData);
  }, [userData.data, userData.loading, currentUser]);

  if (loading) return <LoadingOverlay />;
  if (error || data === undefined) return <ErrorOverlay />;

  return (
    <div>
      {activeWarningState && activeWarningState.enabled && !userData.error ? (
        <WarningBar {...activeWarningState} />
      ) : null}
      <GlobalHeader />
      <div style={styles.leftNavAndScreenContent}>
        <LeftNav />
        <ScreenContent />
      </div>
    </div>
  );
};

export default HomeScreen;
