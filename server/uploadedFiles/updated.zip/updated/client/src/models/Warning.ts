export interface Warning {
  readonly _id: string;
  type: string;
  readonly label: string;
  enabled: boolean;
}

export interface WarningGQLResponse {
  readonly getWarnings: Warning[];
}
