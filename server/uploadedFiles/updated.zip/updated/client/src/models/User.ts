import {Warning} from './Warning';

export interface User {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  activeWarnings?: Warning;
}

export interface UserGQLResponse {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  activeWarnings?: Warning;
}
