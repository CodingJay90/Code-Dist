import {atom} from 'recoil';
import {Warning} from '../models/Warning';

const showAdminModalState = atom<boolean>({
  key: 'showAdminModal',
  default: false,
});

const selectedWarning = atom<Warning | null>({
  key: 'selectedWarning',
  default: null,
});

export {showAdminModalState, selectedWarning};
