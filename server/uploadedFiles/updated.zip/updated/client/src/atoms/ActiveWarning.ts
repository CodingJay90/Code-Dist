import {atom} from 'recoil';
import {Warning} from '../models/Warning';

const activeWarning = atom<Warning | null>({
  key: 'activeWarning',
  default: null,
});

export {activeWarning};
