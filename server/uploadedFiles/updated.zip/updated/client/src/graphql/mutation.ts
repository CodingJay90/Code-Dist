import {gql} from '@apollo/client';

export const ENABLE_WARNING = gql`
  mutation EnableWarning($_id: MongoID!, $record: UpdateByIdWarningInput!) {
    updateWarningById(_id: $_id, record: $record) {
      record {
        _id
        type
        label
        enabled
      }
    }
  }
`;

export const UPDATE_USERS_WARNING = gql`
  mutation UpdateUsersWarning($type: String!, $label: String!) {
    updateUsersWarning(type: $type, label: $label)
  }
`;

export const DISABLE_USERS_WARNING = gql`
  mutation DisableUsersWarning {
    disableUsersWarning
  }
`;

export const DISABLE_USER_WARNING = gql`
  mutation DisableUserWarning($_id: String!) {
    disableUserWarning(_id: $_id) {
      _id
    }
  }
`;

export const CREATE_WARNINGS = gql`
  mutation CreateMultipleWarnings($records: [CreateManyWarningInput!]!) {
    createMultipleWarnings(records: $records) {
      records {
        _id
        type
        label
      }
    }
  }
`;

export const ENABLE_USERS_NOTIFICATION = gql`
  mutation UpdateUsersWarning($record: UpdateManyUserInput!) {
    userUpdateMany(record: $record) {
      numAffected
    }
  }
`;

export const UPDATE_USER_NOTIFICATION = gql`
  mutation UpdateUserWarning($_id: MongoID!, $record: UpdateByIdUserInput!) {
    userUpdateById(_id: $_id, record: $record) {
      record {
        _id
        activeWarning {
          type
          label
          enabled
        }
      }
    }
  }
`;
