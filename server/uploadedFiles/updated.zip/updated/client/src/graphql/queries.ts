import {gql} from '@apollo/client';

export const GET_USER_DETAILS = gql`
  query GetUser($_id: MongoID!) {
    userById(_id: $_id) {
      _id
      activeWarning {
        _id
        type
        label
        enabled
      }
    }
  }
`;

export const GET_NOTIFICATIONS = gql`
  query GetWarnings {
    getWarnings {
      _id
      type
      label
      enabled
    }
  }
`;
