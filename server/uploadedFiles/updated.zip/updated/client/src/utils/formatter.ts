export const formatWarningType = (str: string): string =>
  str.replace(/_/g, ' ');
