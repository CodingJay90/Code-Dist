import {MockedProvider} from '@apollo/client/testing';
import {RecoilRoot} from 'recoil';
import {fireEvent, render} from '@testing-library/react';

import {RecoilObserver} from '../components/RecoilObserver';
import {GET_NOTIFICATIONS} from '../graphql/queries';
import AdminConsoleModal from '../components/admin/AdminConsoleModal';
import AdminDropDown from '../components/admin/AdminDropDown';
import {selectedWarning, showAdminModalState} from '../atoms/AdminConsole';

const mocks = [
  {
    request: {
      query: GET_NOTIFICATIONS,
    },
    result: {
      data: {
        getWarnings: [
          {
            _id: '62a168fc62fbfd06dfdab3f4',
            type: 'Download_Server_Unavailable_Warning',
            label:
              "We are currently experiencing issues with our download server, we're working on fixing it as soon as possible.",
            enabled: true,
          },
          {
            _id: '62a168fc62fbfd06dfdab3f5',
            type: 'Upload_Server_Unavailable_Warning',
            label:
              "We are currently experiencing issues with our upload server, we're working on fixing it as soon as possible.",
            enabled: false,
          },
          {
            _id: '62a168fc62fbfd06dfdab3f6',
            type: 'Data_Inconsistency_Warning',
            label:
              "We are currently experiencing some issues with our data consistency, we're working on fixing it as soon as possible.",
            enabled: false,
          },
        ],
      },
    },
  },
];

const mockData = [
  {
    _id: '62a168fc62fbfd06dfdab3f4',
    type: 'Download_Server_Unavailable_Warning',
    label:
      "We are currently experiencing issues with our download server, we're working on fixing it as soon as possible.",
    enabled: true,
  },
  {
    _id: '62a168fc62fbfd06dfdab3f5',
    type: 'Upload_Server_Unavailable_Warning',
    label:
      "We are currently experiencing issues with our upload server, we're working on fixing it as soon as possible.",
    enabled: false,
  },
  {
    _id: '62a168fc62fbfd06dfdab3f6',
    type: 'Data_Inconsistency_Warning',
    label:
      "We are currently experiencing some issues with our data consistency, we're working on fixing it as soon as possible.",
    enabled: false,
  },
];

it('renders admin dropdown without error ', async () => {
  const onChange = jest.fn();
  const {findByText} = render(
    <MockedProvider mocks={mocks} addTypename={false}>
      <RecoilRoot>
        <RecoilObserver node={showAdminModalState} onChange={onChange} />
        <AdminConsoleModal />
      </RecoilRoot>
    </MockedProvider>
  );

  expect(await findByText(/Start a site-side warning/i)).toBeInTheDocument();
  expect(await findByText(/Admin Console/i)).toBeInTheDocument();
});

it('shows the correct text on the dropdown onclick', async () => {
  const onClick = jest.fn();

  const {getByTestId, findByText} = render(
    <RecoilRoot>
      <RecoilObserver node={selectedWarning} onChange={onClick} />
      <AdminDropDown notificationsData={mockData} />
    </RecoilRoot>
  );

  const component = getByTestId('dropdown1');

  fireEvent.click(component, {
    _id: '62a168fc62fbfd06dfdab3f4',
    type: 'Download_Server_Unavailable_Warning',
    label:
      "We are currently experiencing issues with our download server, we're working on fixing it as soon as possible.",
    enabled: true,
  });

  expect(onClick).toHaveBeenCalledTimes(2); // Initial state on render.
  expect(
    await findByText(/Download Server Unavailable Warning/i)
  ).toBeInTheDocument();
});
