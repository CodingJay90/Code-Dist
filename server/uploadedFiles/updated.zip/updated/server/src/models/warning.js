import mongoose, { Schema } from 'mongoose';
import timestamps from 'mongoose-timestamp';
import { composeWithMongoose } from 'graphql-compose-mongoose';

export const WarningSchema = new Schema(
    {
        type: {
            type: String,
            trim: true,
            required: true,
            enum: [
                'Download_Server_Unavailable_Warning',
                'Upload_Server_Unavailable_Warning',
                'Data_Inconsistency_Warning',
            ],
            unique: true,
        },
        label: {
            type: String,
            trim: true,
            required: true,
        },
        enabled: {
            type: Boolean,
            required: true,
            default: false,
        },
    },
    {
        collection: 'warnings',
    }
);

WarningSchema.plugin(timestamps);

export const Warning = mongoose.model('Warning', WarningSchema);
export const WarningTC = composeWithMongoose(Warning);
