import { WarningTC } from '../models/warning';

const WarningQuery = {
    getWarningById: WarningTC.getResolver('findById'),
    getWarning: WarningTC.getResolver('findOne'),
    getWarnings: WarningTC.getResolver('findMany'),
};

const WarningMutation = {
    createWarning: WarningTC.getResolver('createOne'),
    createMultipleWarnings: WarningTC.getResolver('createMany'),
    updateWarningById: WarningTC.getResolver('updateById'),
    updateOneWarning: WarningTC.getResolver('updateOne'),
};

export { WarningQuery, WarningMutation };
