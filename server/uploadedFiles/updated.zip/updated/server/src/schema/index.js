import { SchemaComposer } from 'graphql-compose';
import { UserTC, User } from '../models/user';
import { WarningQuery, WarningMutation } from './warning';

const schemaComposer = new SchemaComposer();

import { UserQuery, UserMutation } from './user';

schemaComposer.Query.addFields({
    ...UserQuery,
    ...WarningQuery,
});

schemaComposer.Mutation.addFields({
    ...UserMutation,
    ...WarningMutation,
    updateUsersWarning: {
        type: 'String',
        args: {
            type: 'String!',
            label: 'String!',
        },
        resolve: async (_, args) => {
            await User.updateMany(
                {},
                {
                    $set: {
                        activeWarning: {
                            type: args.type,
                            label: args.label,
                            enabled: true,
                        },
                    },
                }
            );
            return 'ok';
        },
    },
    disableUsersWarning: {
        type: 'String',
        resolve: async () => {
            const users = await User.find({});
            users.forEach(async (user) => {
                user.activeWarning.remove();
                await user.save();
            });
            return 'ok';
        },
    },
    disableUserWarning: {
        type: UserTC,
        args: {
            _id: 'String!',
        },
        resolve: async (_, args) => {
            const user = await User.findById(args?._id);
            user.activeWarning.remove();
            await user.save();
            return user;
        },
    },
});

export default schemaComposer.buildSchema();
