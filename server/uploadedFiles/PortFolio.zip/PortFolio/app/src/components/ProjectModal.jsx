import React, { useEffect, useState } from "react";
import ProjectCard from "./ProjectCard";

const Card = (props) => {
  return (
    <li className="card">
      <ProjectCard project={props.project} />
    </li>
  );
};

const ProjectModal = ({ projects }) => {
  const [moveClass, setMoveClass] = useState("");
  const [carouselItems, setCarouselItems] = useState(projects);

  useEffect(() => {
    document.documentElement.style.setProperty("--num", carouselItems.length);
  }, [carouselItems]);

  const handleAnimationEnd = () => {
    if (moveClass === "prev") {
      shiftNext([...carouselItems]);
    } else if (moveClass === "next") {
      shiftPrev([...carouselItems]);
    }
    setMoveClass("");
  };

  const shiftPrev = (copy) => {
    let lastcard = copy.pop();
    copy.splice(0, 0, lastcard);
    setCarouselItems(copy);
  };

  const shiftNext = (copy) => {
    let firstcard = copy.shift();
    copy.splice(copy.length, 0, firstcard);
    setCarouselItems(copy);
  };

  return (
    <div className="overlay wrap" id="show">
      <div className="carouselwrapper module-wrapper">
        <a href="#Projects" className="modal-close" title="Close Modal">
          X
        </a>
        <h3>More noteworthy projects</h3>
        <div className="ui">
          <button onClick={() => setMoveClass("next")} className="prev">
            <span className="material-icons">chevron_left</span>
          </button>
          <button onClick={() => setMoveClass("prev")} className="next">
            <span className="material-icons">chevron_right</span>
          </button>
        </div>
        <ul
          onAnimationEnd={handleAnimationEnd}
          className={`${moveClass} carousel`}
        >
          {carouselItems.map((t, index) => (
            <Card key={index} project={t} icon={t.icon} copy={t.copy} />
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ProjectModal;
