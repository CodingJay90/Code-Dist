import React, { useState } from "react";
import bgImage from "../assets/images/surface-CIrJuUI75hg-unsplash.jpg";
const ContactModal = () => {
  const [submitted, setSubmitted] = useState(false);
  const [formValues, setFormValues] = useState({
    email: "",
    name: "",
    message: "",
  });
  async function submitMessage(e) {
    e.preventDefault();
    try {
      await fetch(`https://formsubmit.co/ajax/akoladefaruq42@gmail.com`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          ...formValues,
        }),
      });
      setSubmitted(true);
    } catch (error) {
      console.log(error);
    }
  }

  const handleChange = (e) =>
    setFormValues({ ...formValues, [e.target.name]: e.target.value });

  return (
    <>
      <div className="popup" id="popup">
        <div className="popup-inner">
          <div className="popup__photo">
            <img src={bgImage} alt="" />
          </div>
          <div className="popup__text">
            {!submitted ? (
              <>
                <h1>Leave me a message</h1>
                <form target="_blank" method="POST" onSubmit={submitMessage}>
                  <input
                    onChange={handleChange}
                    required
                    type="email"
                    name="email"
                    placeholder="Your Email"
                  />
                  <input
                    onChange={handleChange}
                    required
                    type="text"
                    name="name"
                    placeholder="Your Name"
                  />
                  <textarea
                    onChange={handleChange}
                    required
                    name="message"
                    cols="30"
                    rows="10"
                  ></textarea>
                  <button>Submit</button>
                </form>
              </>
            ) : (
              <p>Thanks for reaching out 🙂</p>
            )}
          </div>
          <a className="popup__close" href="#contact">
            X
          </a>
        </div>
      </div>
    </>
  );
};

export default ContactModal;
