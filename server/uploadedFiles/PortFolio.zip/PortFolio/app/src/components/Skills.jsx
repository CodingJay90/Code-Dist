import React from "react";

const Skills = () => {
  return (
    <section className="skills" id="skills">
      <div className="skills__container">
        <div className="skills__header">
          <h1>Skills and Work Experience</h1>
        </div>
        <div className="skills__wrapper"></div>
      </div>
    </section>
  );
};

export default Skills;
