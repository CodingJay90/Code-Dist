import React from "react";
import {
  FaTwitterSquare,
  FaTwitter,
  FaInstagram,
  FaGithub,
} from "react-icons/fa";
const Footer = () => {
  return (
    <div className="footer">
      <div className="footer__wrapper">
        <p>
          2022 © Faruq Akolade |{" "}
          <a target="_blank" href="https://github.com/CodingJay90">
            <FaGithub />
          </a>{" "}
          |{" "}
          <a target="_blank" href="https://www.instagram.com/randdom_addvice/">
            <FaInstagram />
          </a>{" "}
          |{" "}
          <a target="_blank" href="https://twitter.com/Randdom_addvice">
            <FaTwitter />
          </a>
        </p>
      </div>
    </div>
  );
};

export default Footer;
