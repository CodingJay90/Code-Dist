import React from "react";
import { Link } from "react-scroll";
import navLogo from "../assets/images/brandLogo.svg";
import { HiMenuAlt3 } from "react-icons/hi";

const Navigation = () => {
  return (
    <nav className="nav">
      <div className="nav__wrapper">
        <input type="checkbox" className="nav__checkbox" id="nav-toggle" />
        <label htmlFor="nav-toggle" className="nav__button">
          <HiMenuAlt3 />
        </label>
        <div className="nav__toggler"></div>
        <div className="nav__group">
          <div className="nav__group-item">
            <div className="nav__brand">
              <Link to="home" smooth={true}>
                <img src={navLogo} alt="nav logo" />
              </Link>
            </div>
          </div>
        </div>
        <div className="nav__group">
          <div className="nav__group-item">
            <div className="nav__group-item-link">
              <Link to="home" smooth={true}>
                <span>01. </span>
                Home
              </Link>
            </div>
            <div className="nav__group-item-link">
              <Link to="about" smooth={true}>
                <span>02. </span>
                About
              </Link>
            </div>
            <div className="nav__group-item-link">
              <Link to="project" smooth={true}>
                <span>03. </span>
                Projects
              </Link>
            </div>
            <div className="nav__group-item-link">
              <Link to="contact" smooth={true}>
                <span>04. </span>
                Contact
              </Link>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
