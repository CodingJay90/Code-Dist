import React from "react";
import ProfilePic from "../assets/images/me.jpg";
import { FaCaretRight } from "react-icons/fa";

const About = () => {
  return (
    <section className="about section" id="about">
      <div className="about__container">
        <h1 className="about__header">About Me</h1>
        <div className="about__desc">
          <div className="about__desc-text">
            <p>
              Dedicated Full-stack Web Developer professional with a history of
              meeting company goals utilizing consistent and organized
              practices.
            </p>
            <p>
              Skilled in working under pressure and adapting to new situations
              and challenges to best enhance the organizational brand. Excellent
              reputation for resolving problems and improving customer
              satisfaction.
            </p>
            <p>Here are a few technologiesI've been working with:</p>
            <ul>
              <li>
                <span>
                  <FaCaretRight />
                </span>
                Javascript / Node.js
              </li>
              <li>
                <span>
                  <FaCaretRight />
                </span>
                Typescript
              </li>
              <li>
                <span>
                  <FaCaretRight />
                </span>
                REST API
              </li>
              <li>
                <span>
                  <FaCaretRight />
                </span>
                React.js
              </li>
              <li>
                <span>
                  <FaCaretRight />
                </span>
                Vue.Js
              </li>
              <li>
                <span>
                  <FaCaretRight />
                </span>
                GIT
              </li>
              <li>
                <span>
                  <FaCaretRight />
                </span>
                Websocket
              </li>
              <li>
                <span>
                  <FaCaretRight />
                </span>
                Deployment
              </li>
              <li>
                <span>
                  <FaCaretRight />
                </span>
                GraphQL
              </li>
              <li>
                <span>
                  <FaCaretRight />
                </span>
                Databases
              </li>
            </ul>
          </div>
          <div className="about__desc-img">
            <img width="300" height="300" src={ProfilePic} alt="Me" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
