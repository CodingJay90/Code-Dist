import React from "react";
import { AiOutlineMail, AiOutlinePhone, AiOutlineGithub } from "react-icons/ai";

const Contact = () => {
  return (
    <section className="contact section" id="contact">
      <div className="contact__container">
        <h1 className="contact__header">Contact me</h1>
      </div>
      <div className="contact__wrapper">
        <div className="gallery">
          <a href="tel:+2349068249871" className="box box1">
            <div>
              <div className="contact__card">
                <div className="contact__card-icon">
                  <span>
                    <AiOutlinePhone />
                  </span>
                </div>
                <h4>Phone</h4>
                <a href="tel:+2349068249871">9068249871</a>
              </div>
            </div>
          </a>

          <a href="mailto:akoladefaruq42@gmail.com" className="box box2">
            <div>
              <div className="contact__card">
                <div className="contact__card-icon">
                  <span>
                    <AiOutlineMail />
                  </span>
                </div>
                <h4>Email</h4>
                <a href="mailto:akoladefaruq42@gmail.com">
                  akoladefaruq42@gmail.com
                </a>
              </div>
            </div>
          </a>

          <a
            href="https://github.com/codingjay90"
            target="_blank"
            className="box box3 "
          >
            <div>
              <div className="contact__card">
                <div className="contact__card-icon">
                  <span>
                    <AiOutlineGithub />
                  </span>
                </div>
                <h4>Github</h4>
                <a href="https://github.com/codingjay90" target="_blank">
                  Codingjay90
                </a>
              </div>
            </div>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Contact;
