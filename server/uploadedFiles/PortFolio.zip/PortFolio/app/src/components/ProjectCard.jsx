import React from "react";
import { FaGithub, FaExternalLinkAlt } from "react-icons/fa";

const ProjectCard = ({ project }) => {
  return (
    <>
      <div className="project__card">
        <div className="project__card-header">
          <div className="project__card-header-dots">
            <div className="project__card-header-dot"></div>
            <div className="project__card-header-dot"></div>
            <div className="project__card-header-dot"></div>
          </div>
          <div>
            <a href={project.gh_link} className="project__card-header-links">
              <FaGithub />
            </a>
            <a
              href={project.deployed_link}
              className="project__card-header-links"
            >
              <FaExternalLinkAlt />
            </a>
          </div>
        </div>
        <div className="project__card-title r-link animated-underline animated-underline_type4 news__link">
          <svg xmlns="http://www.w3.org/2000/svg">
            <filter id="motion-blur-filter" filterUnits="userSpaceOnUse">
              <feGaussianBlur stdDeviation="100 0"></feGaussianBlur>
            </filter>
          </svg>
          <span filter-content="S">{project.name}</span>
        </div>
        <div className="project__card-description">{project.description}</div>
        <div className="project__card-footer">
          <div className="project__card-footer-tags">
            {project.tags.map((i, ix) => (
              <span key={ix}>{i}</span>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default ProjectCard;
