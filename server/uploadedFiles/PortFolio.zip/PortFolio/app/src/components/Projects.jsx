import React from "react";
import ProjectCard from "./ProjectCard";
import ProjectModal from "./ProjectModal";
const Projects = () => {
  const projects = [
    {
      name: "Wild traveller v2 (typescript)",
      description:
        "Wild traveller is a Travel sharing platform, where users can share their travel experiences with other users.",
      deployed_link: "https://wildtraveller.netlify.app/",
      gh_link:
        "https://github.com/CodingJay90/Wild-traveller-typescript-version",
      tags: ["React", "Node.js/express", "Typescript"],
    },
    {
      name: "DMMeee",
      description: "DMMee is a messaging app built using react and firebase",
      deployed_link: "https://fir-9-simple-chatapp.web.app/register",
      gh_link: "https://github.com/CodingJay90/DMmee",
      tags: ["React", "Firebase", "SCSS"],
    },
    {
      name: "Sendit parcel",
      description: "Sendit is a parcel delivery platform",
      deployed_link: "https://sendit-contextapi.netlify.app",
      gh_link: "https://github.com/CodingJay90/senditContextApi",
      tags: ["React", "Node.js/express", "Postgresql"],
    },
    {
      name: "Tradee (in development)",
      description: "A trading platform for traders to improve their skills",
      deployed_link: "https://github.com/CodingJay90/equity_curve",
      gh_link: "https://github.com/CodingJay90/equity_curve",
      tags: ["Javascript", "Node.js/express", "Mongodb"],
    },
    {
      name: "sendit (vanillajs)",
      description:
        "Sendit (vanillajs) is the second verison of the original sendit parcel built using vanillajs with no framework",
      deployed_link: "https://sendit-vanillajs.herokuapp.com/",
      gh_link: "https://github.com/CodingJay90/sendit-vanillaJs",
      tags: ["Javascript", "CSS", "Heroku"],
    },
  ];
  return (
    <section className="project section" id="project">
      <div className="project__container">
        {/* <h1 className="projects__header">Some of the projects I've built</h1> */}
        <h1 className="project__header">Projects</h1>
        {/* <div className="projects__wrapper"> */}
        {projects.slice(0, 3).map((project, index) => (
          <ProjectCard project={project} key={index} />
        ))}
        <a href="#show" className="project__btn ">
          View more projects
        </a>
        <ProjectModal projects={projects.splice(3, projects.length)} />
      </div>
    </section>
    // </div>
  );
};

export default Projects;
