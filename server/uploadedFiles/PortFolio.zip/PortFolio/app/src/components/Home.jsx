import React from "react";

const Home = () => {
  return (
    <section className="home section" id="home">
      <div className="home__container">
        <div className="home__content">
          <div className="home__content-wrapper">
            <h1 className="home__content-heading">G'Day, I'm Faruq!</h1>
            <h3 className="home__content-subHeading">
              I build things for the web.
            </h3>
            <p className="home__content-description">
              I'm a software developer with experience in JavaScript, and
              frontend and backend frameworks. I enjoy solving problems
              creatively and succinctly.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Home;
