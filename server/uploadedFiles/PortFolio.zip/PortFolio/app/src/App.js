import "./assets/projectModal.scss";
import "./assets/styles.scss";
import "./assets/modal.scss";
import Navigation from "./components/Navigation";
import Home from "./components/Home";
import About from "./components/About";
import Projects from "./components/Projects";
import Contact from "./components/Contact";
import { BsFillChatFill } from "react-icons/bs";
import ContactModal from "./components/ContactModal";
import Footer from "./components/Footer";
function App() {
  return (
    <div className="App">
      <div id="grainy"></div>
      <Navigation />
      <main>
        <aside></aside>
        <Home />
        <About />
        <Projects />
        <Contact />
        <aside className="message__toggle" style={{ padding: 0 }}>
          <a href="#popup" className="message__toggle">
            <BsFillChatFill />
          </a>
        </aside>
        <ContactModal />
      </main>
      <Footer />
    </div>
  );
}

export default App;
