AOS.init({
  mirror: true,
  offset: 180,
});

window.onscroll = function () {
  scrollFunction();
};

function scrollFunction() {
  if (
    document.body.scrollTop > 100 ||
    document.documentElement.scrollTop > 80
  ) {
    document.querySelector("nav").style.height = "74px";
  } else {
    document.querySelector("nav").style.height = "120px";
  }
}
